import React from 'react'
function Template404() {
    return (
        <div style={{display: "flex", justifyContent: "center", alignItems: "center", height: "100%",}}>Page Not Found..!</div>
    )
}
export default Template404
